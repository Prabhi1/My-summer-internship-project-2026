# Machine Learning Based Predictive Maintenance and Equipment Failure Prediction

## Project Overview
This project explores a Machine Learning based approach for predictive maintenance and equipment failure prediction. The workflow covers data loading, preprocessing, exploratory data analysis, feature selection, model training, prediction, and evaluation.

## Objectives
- Analyze machine/equipment-related data.
- Preprocess and clean the dataset.
- Identify useful features associated with equipment condition.
- Train a Machine Learning classification model.
- Evaluate model performance using standard metrics.
- Provide a foundation for future real-time Industrial IoT integration.

## Technology Stack
- Python
- NumPy
- Pandas
- Matplotlib
- Scikit-learn
- Jupyter Notebook

## Project Structure
```text
predictive-maintenance/
├── data/
│   ├── README.md
│   └── sample_machine_data.csv
├── notebooks/
│   └── predictive_maintenance.ipynb
├── src/
│   └── predictive_maintenance.py
├── results/
│   └── README.md
├── docs/
│   └── project_report.docx
├── requirements.txt
├── .gitignore
└── README.md
```

## Workflow
Machine/Sensor Data
→ Data Preprocessing
→ Exploratory Data Analysis
→ Feature Selection
→ Model Training
→ Prediction
→ Performance Evaluation

## How to Run
1. Install Python 3.10+.
2. Install dependencies:
   `pip install -r requirements.txt`
3. Place the project dataset in `data/`.
4. Run:
   `python src/predictive_maintenance.py`

## Important Note
The final repository should contain the actual dataset/model results used during the internship. Sample data included in this starter package is only for demonstrating the project structure and should not be presented as the official internship dataset.

## Author
Prabhi Rani

## Internship
Industrial Internship – upskill Campus & The IoT Academy in collaboration with UniConverge Technologies Pvt. Ltd. (UCT)
