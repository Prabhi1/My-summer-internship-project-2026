import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

DATA_PATH = Path("data/sample_machine_data.csv")

def main():
    df = pd.read_csv(DATA_PATH)

    print("Dataset shape:", df.shape)
    print("\nMissing values:\n", df.isnull().sum())

    # Replace this target/feature selection with the actual internship dataset columns.
    target = "failure"
    features = [c for c in df.columns if c != target]

    X = df[features]
    y = df[target]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)

    print("\nEvaluation")
    print("Accuracy :", accuracy_score(y_test, predictions))
    print("Precision:", precision_score(y_test, predictions, zero_division=0))
    print("Recall   :", recall_score(y_test, predictions, zero_division=0))
    print("F1-score :", f1_score(y_test, predictions, zero_division=0))
    print("\nClassification Report:\n")
    print(classification_report(y_test, predictions, zero_division=0))

if __name__ == "__main__":
    main()
