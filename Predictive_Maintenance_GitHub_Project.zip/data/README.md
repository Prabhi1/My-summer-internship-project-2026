# Dataset

Place the actual internship dataset in this folder.

Recommended columns depend on the assigned dataset. Typical predictive-maintenance features may include:
- temperature
- rotational_speed
- torque
- pressure
- vibration
- operating_hours
- failure

Do not upload confidential, proprietary, personal, or restricted industrial data without permission.
